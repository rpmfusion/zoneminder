ALTER TABLE Users MODIFY MonitorIds text;
