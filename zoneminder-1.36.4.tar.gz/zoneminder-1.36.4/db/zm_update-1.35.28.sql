ALTER TABLE `Monitors` MODIFY `Encoder`     varchar(32);
