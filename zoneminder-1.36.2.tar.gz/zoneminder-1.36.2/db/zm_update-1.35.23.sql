
UPDATE `Controls` SET `Protocol`='FoscamCGI' where `Protocol`='onvif';
