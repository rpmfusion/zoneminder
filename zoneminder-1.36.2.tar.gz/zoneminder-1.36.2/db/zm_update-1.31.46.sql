ALTER TABLE Stats MODIFY COLUMN EventId bigint unsigned NOT NULL;

