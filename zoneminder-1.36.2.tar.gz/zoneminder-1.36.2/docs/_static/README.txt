The external link icon is GPL licensed. Original license link:
https://commons.wikimedia.org/wiki/Category:External_link_icons#/media/File:Icon_External_Link.png
