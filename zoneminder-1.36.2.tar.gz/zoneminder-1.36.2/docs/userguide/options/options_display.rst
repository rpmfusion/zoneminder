Options - Display
-----------------

This option screen allows user to select the skin for ZoneMinder. Currently available styles  are:

.. image:: images/Options_Display.png





