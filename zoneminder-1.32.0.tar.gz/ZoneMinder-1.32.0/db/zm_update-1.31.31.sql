ALTER TABLE Storage MODIFY DiskSpace BIGINT default NULL;
