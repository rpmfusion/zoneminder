ALTER TABLE Monitors MODIFY TotalEventDiskSpace BIGINT default NULL;
ALTER TABLE Monitors MODIFY Method VARCHAR(16) default NULL;

