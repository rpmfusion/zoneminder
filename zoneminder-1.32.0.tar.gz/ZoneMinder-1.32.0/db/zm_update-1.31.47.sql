ALTER TABLE Frames MODIFY COLUMN EventId bigint unsigned NOT NULL;

